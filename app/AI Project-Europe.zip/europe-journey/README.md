
# Europe Journey (Next.js)

A clean, interactive map + timeline site for your Europe trip.

## Local Setup

```bash
npm install
npm run dev
```

Then open http://localhost:3000

## Deploy to Vercel (recommended)

1. Create a new GitHub repo and push this folder.
2. Go to https://vercel.com/new and import the repo.
3. Build settings: framework **Next.js**. No special env vars needed.
4. Click **Deploy**. Done.

## Notes
- Map uses OpenStreetMap via Leaflet. 
- You can add stops (title/date/lat/lng/photos/videos) from the form on the page.
- Replace the sample photos with your own later.
