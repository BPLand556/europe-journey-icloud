export const metadata = {
  title: "Ben's Europe — 2025",
  description: "Interactive map, timeline, and gallery for the trip.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
